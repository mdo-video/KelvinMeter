package com.mdo.kelvinmeter

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.View
import androidx.core.graphics.ColorUtils
import com.google.android.material.R as MR
import com.google.android.material.color.MaterialColors

/** Colori del tema Material 3 (gli stessi usati da Vicino e Motion Cues). */
class Colors(
    val surface: Int,
    val onSurface: Int,
    val onVariant: Int,
    val cardBg: Int,
    val primary: Int,
    val primaryContainer: Int,
    val onPrimaryContainer: Int
)

/** Palette dell'app: caldo -> freddo. */
object Pal {
    val COLD: Int = Color.parseColor("#4FC3F7")
    val MID: Int = Color.parseColor("#FFC107")
    val HOT: Int = Color.parseColor("#FF7043")
    val DARK: Int = Color.parseColor("#12161C")
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
fun View.dp(v: Int): Int = context.dp(v)

fun Context.colors(): Colors {
    fun c(attr: Int, def: Int): Int = MaterialColors.getColor(this, attr, def)
    return Colors(
        c(MR.attr.colorSurface, Color.WHITE),
        c(MR.attr.colorOnSurface, Color.BLACK),
        c(MR.attr.colorOnSurfaceVariant, Color.DKGRAY),
        c(MR.attr.colorSurfaceContainerHigh, Color.LTGRAY),
        c(MR.attr.colorPrimary, Color.BLUE),
        c(MR.attr.colorPrimaryContainer, Color.LTGRAY),
        c(MR.attr.colorOnPrimaryContainer, Color.BLACK)
    )
}

fun Context.roundBg(color: Int, radiusDp: Int): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = dp(radiusDp).toFloat()
    return g
}

const val K_MIN = 2000f
const val K_MAX = 10000f

/** 0 = 2000 K (caldissimo), 1 = 10000 K (freddissimo). */
fun kFrac(k: Float): Float = ((k - K_MIN) / (K_MAX - K_MIN)).coerceIn(0f, 1f)

/** Caldo = arancio, neutro = giallo, freddo = azzurro. */
fun kColor(k: Float): Int {
    val h = 1f - kFrac(k) // 1 = caldo
    return if (h < 0.5f) ColorUtils.blendARGB(Pal.COLD, Pal.MID, h * 2f)
    else ColorUtils.blendARGB(Pal.MID, Pal.HOT, (h - 0.5f) * 2f)
}
